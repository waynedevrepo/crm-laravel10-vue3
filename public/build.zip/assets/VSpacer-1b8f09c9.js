import{c as e}from"./VAvatar-a5393c1e.js";const a=e("flex-grow-1","div","VSpacer");export{a as V};
